import hlt.*;

import java.util.ArrayList;

public class MyBot {

    public static void main(final String[] args) {
        final Networking networking = new Networking();
        final GameMap gameMap = networking.initialize("TobySuch");

        final ArrayList<Move> moveList = new ArrayList<>();
        final ArrayList<Planet> unownedPlanets = new ArrayList<>();
        final ArrayList<Planet> ownedPlanets = new ArrayList<>();

        for (;;) {
            moveList.clear();
            unownedPlanets.clear();
            ownedPlanets.clear();
            gameMap.updateMap(Networking.readLineIntoMetadata());

            for (Planet planet : gameMap.getAllPlanets().values()) {
                if (planet.isOwned()) {
                    ownedPlanets.add(planet);
                } else {
                    unownedPlanets.add(planet);
                }
            }

            for (final Ship ship : gameMap.getMyPlayer().getShips().values()) {
                if (ship.getDockingStatus() != Ship.DockingStatus.Undocked) {
                    continue;
                }

                Planet targetPlanet = null;
                double closestDistance = -1;
                for (Planet planet : unownedPlanets) {
                    double distance = ship.getDistance(planet);
                    if (closestDistance == -1 | distance < closestDistance) {
                        targetPlanet = planet;
                        closestDistance = distance;
                    }
                }

                if (targetPlanet == null) {
                    DebugLog.addLog("Did not find unowned planet");
                    closestDistance = -1;
                    for (Planet planet : ownedPlanets) {
                        if (planet.getOwner() != gameMap.getMyPlayer().getId()) {
                            double distance = ship.getDistance(planet);
                            if (closestDistance == -1 | distance < closestDistance) {
                                targetPlanet = planet;
                                closestDistance = distance;
                            }
                        }
                    }
                } else {
                    DebugLog.addLog("Found unowned planet");
                }

                if (targetPlanet != null) {
                    if (targetPlanet.isOwned()) {
                        DebugLog.addLog("Found owned planet");
                    }

                    if (ship.canDock(targetPlanet)) {
                        moveList.add(new DockMove(ship, targetPlanet));
                        continue;
                    }

                    final ThrustMove newThrustMove = Navigation.navigateShipToDock(gameMap, ship, targetPlanet, Constants.MAX_SPEED);
                    if (newThrustMove != null) {
                        moveList.add(newThrustMove);
                    }
                }
            }
            Networking.sendMoves(moveList);
        }
    }
}
